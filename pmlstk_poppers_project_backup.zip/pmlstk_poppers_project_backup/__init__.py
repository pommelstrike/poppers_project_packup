bl_info = {
    "name": "Popper's Offline Project Backup",
    "author": "pommelstrike",
    "version": (1, 5),
    "blender": (3, 0, 0),
    "location": "Properties > Output > Output > BG3 Data Backup",
    "description": "Backs up specified folders from a /Data directory with optional zipping, have a treato. You will find this UI menu under the Printer Icon in the Properties, under the camera icon, then scroll down to Output ",
    "category": "System",
}

import bpy
import os
import shutil
from datetime import datetime
import zipfile
import bpy.utils.previews

# Global variable for custom icons
custom_icons = "EVENT_P"

# === OPERATOR FOR BACKUP ===
class BG3BACKUP_OT_backup(bpy.types.Operator):
    bl_idname = "bg3backup.backup"
    bl_label = "Run Backup"
    bl_description = "Backs up the specified folder from the Data directory"

    def execute(self, context):
        props = context.scene.bg3backup_props

        # Get inputs from properties
        source_root = props.source_root
        target_folder_name = props.target_folder_name
        target_destination = props.target_destination
        zip_option = props.zip_backup

        # Validate inputs
        if not source_root or not os.path.isdir(source_root):
            self.report({'ERROR'}, "Invalid or missing source path! Ensure the BG3 /Data directory exists.")
            return {'CANCELLED'}
        if not target_folder_name:
            self.report({'ERROR'}, "Folder name cannot be empty!")
            return {'CANCELLED'}
        if not target_destination:
            self.report({'ERROR'}, "Target destination cannot be empty!")
            return {'CANCELLED'}

        # Validate target_destination exists and is writable
        try:
            if not os.path.exists(target_destination):
                os.makedirs(target_destination, exist_ok=True)
            test_file = os.path.join(target_destination, ".test_write")
            with open(test_file, "w") as f:
                f.write("test")
            os.remove(test_file)
        except (OSError, PermissionError) as e:
            self.report({'ERROR'}, f"Cannot write to target destination: {str(e)}")
            return {'CANCELLED'}

        # Backup destination
        sanitized_name = target_folder_name.replace(" ", "_").replace(":", "_")
        backup_folder_name = f"{sanitized_name}_Export_Data"
        backup_root = os.path.join(target_destination, "BG3_Backups", backup_folder_name)

        # Check for path length issues
        if len(backup_root) > 200:
            self.report({'WARNING'}, f"Backup path length ({len(backup_root)} characters) may cause issues. Use a shorter destination path.")

        # Remove existing backup directory to avoid conflicts
        if os.path.exists(backup_root):
            try:
                shutil.rmtree(backup_root)
                self.report({'INFO'}, f"Cleared existing backup directory: {backup_root}")
            except (OSError, PermissionError) as e:
                self.report({'ERROR'}, f"Failed to clear existing backup directory: {str(e)}")
                return {'CANCELLED'}

        # Static subfolders to check, post v7
        subdirs_to_check = [
            "",  # Directly under /Data/
            "Editor\\Mods",
            "Generated\\Public",
            "Mods",
            "Projects",
            "Public"
        ]

        # Backup process
        folders_backed_up = []
        failed_files = []
        for subdir in subdirs_to_check:
            search_path = os.path.join(source_root, subdir, target_folder_name)
            if os.path.isdir(search_path):
                relative_path = os.path.relpath(search_path, source_root)
                backup_path = os.path.join(backup_root, relative_path)

                try:
                    os.makedirs(os.path.dirname(backup_path), exist_ok=True)
                    # Copy files individually to handle errors gracefully
                    for root, dirs, files in os.walk(search_path):
                        rel_root = os.path.relpath(root, search_path)
                        dest_root = os.path.join(backup_path, rel_root)
                        os.makedirs(dest_root, exist_ok=True)
                        for file in files:
                            src_file = os.path.join(root, file)
                            dest_file = os.path.join(dest_root, file)
                            try:
                                if len(dest_file) > 260:
                                    failed_files.append((src_file, dest_file, "Path too long (>260 characters)"))
                                    continue
                                shutil.copy2(src_file, dest_file)
                            except (OSError, shutil.Error) as e:
                                failed_files.append((src_file, dest_file, str(e)))
                                continue
                    folders_backed_up.append((search_path, backup_path))
                except (OSError, shutil.Error) as e:
                    self.report({'WARNING'}, f"Failed to copy folder {search_path} to {backup_path}: {str(e)}")
                    continue

        # Write log file after packup
        if folders_backed_up:
            try:
                os.makedirs(backup_root, exist_ok=True)
                log_filename = f"backup_log_{sanitized_name}.txt"
                log_path = os.path.join(backup_root, log_filename)

                with open(log_path, "w", encoding="utf-8") as log_file:
                    log_file.write("for latest release and support:\n")
                    log_file.write("Patreon: https://www.patreon.com/pommelstrike\n")
                    log_file.write("Website: https://poppers-project-packup.vercel.app/\n")
                    log_file.write("GitHub: https://github.com/pommelstrike/poppers_project_packup\n")
                    log_file.write("\n")
                    log_file.write(f"Backup Log - {datetime.now().strftime('%Y-%m-%d %H:%M:%S')}\n")
                    log_file.write(f"Target Folder: {target_folder_name}\n")
                    log_file.write(f"Source Root: {source_root}\n")
                    log_file.write(f"Backup Destination: {backup_root}\n\n")
                    log_file.write("Copied Folders:\n")
                    for src, dst in folders_backed_up:
                        log_file.write(f"{src} -> {dst}\n")
                    if failed_files:
                        log_file.write("\nFailed Files:\n")
                        for src, dst, error in failed_files:
                            log_file.write(f"{src} -> {dst} (Error: {error})\n")

                self.report({'INFO'}, f"Backed up {len(folders_backed_up)} folder(s). Log saved to: {log_path}")
                if failed_files:
                    self.report({'WARNING'}, f"Some files failed to copy. Check log for details: {log_path}")

                # Zip backup if requested
                if zip_option:
                    zip_filename = os.path.join(target_destination, "BG3_Backups", f"{backup_folder_name}.zip")
                    self.report({'INFO'}, f"Zipping backup to: {zip_filename}")

                    with zipfile.ZipFile(zip_filename, 'w', zipfile.ZIP_DEFLATED) as zipf:
                        for root, _, files in os.walk(backup_root):
                            for file in files:
                                file_path = os.path.join(root, file)
                                arcname = os.path.relpath(file_path, backup_root)
                                zipf.write(file_path, arcname)

                    self.report({'INFO'}, "Backup zipped successfully.")
            except (OSError, zipfile.BadZipFile) as e:
                self.report({'ERROR'}, f"Failed to create log or zip file: {str(e)}")
                return {'CANCELLED'}
        else:
            self.report({'WARNING'}, f"No folders named '{target_folder_name}' found.")

        return {'FINISHED'}

# === PANEL FOR UI ===
class BG3BACKUP_PT_panel(bpy.types.Panel):
    bl_label = "BG3 Data Backup"
    bl_idname = "BG3BACKUP_PT_panel"
    bl_space_type = 'PROPERTIES'
    bl_region_type = 'WINDOW'
    bl_context = 'output'
    bl_parent_id = "RENDER_PT_output"
    bl_icon = "EVENT_P"

    def draw(self, context):
        layout = self.layout
        props = context.scene.bg3backup_props

        layout.label(text="Backup Settings")
        layout.prop(props, "source_root", text="Your BG3 \Data\ Folder Path")
        layout.prop(props, "target_folder_name", text="Insert ProjectName_UUID")
        layout.prop(props, "target_destination", text="Backup Destination Path")
        layout.prop(props, "zip_backup", text="Zip Backup")
        layout.operator("bg3backup.backup", text="Run Backup")

# === PROPERTY GROUP FOR INPUTS ===
class BG3BackupProperties(bpy.types.PropertyGroup):
    source_root: bpy.props.StringProperty(
        name="Source Root",
        description="Path to the /Data folder",
        default="",
        subtype='DIR_PATH'
    )
    target_folder_name: bpy.props.StringProperty(
        name="Target Folder",
        description="Name of the folder to back up",
        default=""
    )
    target_destination: bpy.props.StringProperty(
        name="Target Destination",
        description="Base path for backups (will append \\BG3_Backups)",
        default="",
        subtype='DIR_PATH'
    )
    zip_backup: bpy.props.BoolProperty(
        name="Zip Backup",
        description="Zip the backup folder after copying",
        default=False
    )

# === REGISTER/UNREGISTER ===
classes = (
    BG3BACKUP_OT_backup,
    BG3BACKUP_PT_panel,
    BG3BackupProperties,
)

def register():
    global custom_icons
    try:
        custom_icons = bpy.utils.previews.new()
        for cls in classes:
            bpy.utils.register_class(cls)
        bpy.types.Scene.bg3backup_props = bpy.props.PointerProperty(type=BG3BackupProperties)
    except Exception as e:
        print(f"Error registering BG3 Mod Kit Project Backup: {e}")

def unregister():
    global custom_icons
    try:
        for cls in reversed(classes):
            bpy.utils.unregister_class(cls)
        if hasattr(bpy.types.Scene, 'bg3backup_props'):
            del bpy.types.Scene.bg3backup_props
        if custom_icons:
            bpy.utils.previews.remove(custom_icons)
            custom_icons = None
    except Exception as e:
        print(f"Error unregistering Popper's Project Backup: {e}")

if __name__ == "__main__":
    register()